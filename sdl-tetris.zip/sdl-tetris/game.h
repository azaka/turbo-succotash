
// Prototypes.
void TetrisInit(void);
u32 TetrisMain(void);

void Fade(s32 nFadeVal);



