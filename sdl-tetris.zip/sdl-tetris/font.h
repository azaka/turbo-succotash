
// Prototypes.
void FontPrint(u32 nOffset, char *pStr);
void FontPrintOr(u32 nOffset, char *pStr);
void MyItoa(u32 nNb, char *pDst);

