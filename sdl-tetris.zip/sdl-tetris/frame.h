
// Prototypes.
void FrameInit(void);
void FrameWait(void);


