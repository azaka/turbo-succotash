#ifndef MMC24_H
#define MMC24_H


void register_mmc24();

#endif
